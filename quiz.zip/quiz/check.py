import glob
import os

files = glob.glob("./*")

counter=0

for file in files:
    counter+=1
    path=str(file)
    is_file = os.path.isfile(path)
    if is_file:
        print("OK("+str(counter)+")"+str(path))
    else:
        print("NG("+str(counter)+")"+str(path))
    