import glob
import os

files = glob.glob("./*")
cnt=0

meta=""

with open("./metadata.txt") as f:
    for line in f:
       meta=meta+line

meta=meta.split()

d=dict()

cnt=0
for file in files:
    p=str(file)
    is_file = os.path.isfile(p)
    if is_file:
        cnt+=1
        d[p]=cnt
        #print("OK("+str(p)+")"+str(cnt))
    #else:
        #print("NG("+str(p)+")"+str(cnt))

d2=dict()
cnt2=0
for m in range(len(meta)):
    cnt2+=1
    p="./"+str(meta[m])+".txt"
    d2[p]=cnt2

print("exist:"+str(cnt)+",record:"+str(cnt2))

cnt3=cnt-cnt2
for file in files:
    s=str(file)
    if s =="./quizbot.py" or s=="./quizset.txt" or s=="./quiz.txt" or s=="./metadata.txt" or s=="./check.py" or s=="./quizbot2.py":
        continue
    if s in d2:
        cnt4=0
    else:
        print(str("NoExist:")+str(s))


print(cnt3)